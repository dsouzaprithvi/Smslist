package com.example.smslist.Models;



//To get and set Trip details
public class tripmodel {


    String tripid, date, time, body;

    public tripmodel(String tripid, String date, String time, String body) {
        this.tripid = tripid;
        this.date = date;
        this.time = time;
        this.body = body;

    }

    public tripmodel(String tripid, String date, String time) {
        this.tripid = tripid;
        this.date = date;
        this.time = time;

    }

    public tripmodel(){

    }

    public String getTripid() {
        return tripid;
    }

    public void setTripid(String tripid) {
        this.tripid = tripid;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }


}
