package com.example.smslist.Models;



// To get and set data
public class datamodel {

    String sender, date, time, body;

    public datamodel(String sender, String date, String time, String body) {
        this.sender = sender;
        this.date = date;
        this.time = time;
        this.body = body;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }
}


