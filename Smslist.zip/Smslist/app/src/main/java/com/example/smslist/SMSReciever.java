package com.example.smslist;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

public class SMSReciever extends BroadcastReceiver {


    public static final String SMS_BUNDLE = "pdus";

    


    @Override
    public void onReceive(Context context, Intent intent) {


        Bundle bundle = intent.getExtras();


        if (bundle != null) {
            if (intent.getAction().equals("android.provider.Telephony.SMS_RECEIVED")) {

                Object[] sms = (Object[]) bundle.get("pdus");
                String smsMsg = "";
                SmsMessage smsMessage;

                for (int i = 0; i < sms.length; i++) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        String format = bundle.getString("format");
                        smsMessage = SmsMessage.createFromPdu((byte[]) sms[i], format);

                    } else {
                        smsMessage = SmsMessage.createFromPdu((byte[]) sms[i]);

                    }


                    String msgbody = smsMessage.getMessageBody();
                    String msgaddress = smsMessage.getOriginatingAddress();

                    smsMsg += "SMS from: " + msgaddress + "\n";
                    smsMsg += msgbody + "\n";

                }

                Toast.makeText(context, smsMsg, Toast.LENGTH_LONG).show();
                Log.i("SMS : ", smsMsg);
                //Trip inst = Trip.Instance();
                //inst.updateList(smsMsg);
            }


        }
    }



}
