package com.example.smslist.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smslist.Models.tripmodel;
import com.example.smslist.R;
import com.example.smslist.SMSView;

import java.util.ArrayList;

public class TripsAdapter extends RecyclerView.Adapter<TripsAdapter.tripsViewHolder>{

    ArrayList<tripmodel> tripholder;
    Context context;

    public TripsAdapter(ArrayList<tripmodel> tripholder, Context context) {
        this.tripholder = tripholder;
        this.context = context;

    }


    @NonNull
    @Override
    public TripsAdapter.tripsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_trip, parent, false);
        return new tripsViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull TripsAdapter.tripsViewHolder holder, int position) {

        tripmodel trip = tripholder.get(position);

        holder.tripid.setText(tripholder.get(position).getTripid());
        holder.date.setText(tripholder.get(position).getDate());
        holder.time.setText(tripholder.get(position).getTime());
        holder.body.setText(tripholder.get(position).getBody());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, SMSView.class);
                String trip_body = trip.getBody();
                intent.putExtra("SMS", trip_body);


                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return tripholder.size();
    }

    public class tripsViewHolder extends RecyclerView.ViewHolder{

        TextView tripid, date, time, body;


        public tripsViewHolder(@NonNull View itemView) {
            super(itemView);
            tripid = itemView.findViewById(R.id.trip_id);
            date = itemView.findViewById(R.id.date);
            time = itemView.findViewById(R.id.time);
            body = itemView.findViewById(R.id.body);

        }
    }
}
