package com.example.smslist.Fragments;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.FragmentTransaction;
import android.app.TimePickerDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.smslist.Adapter.SmsAdapter;
import com.example.smslist.Adapter.TrackFragmentsAdapter;
import com.example.smslist.Models.datamodel;
import com.example.smslist.R;
import com.example.smslist.databinding.FragmentTrackBinding;
import com.google.android.material.tabs.TabLayout;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


public class Track extends Fragment {

    TabLayout tabLayout;
    ViewPager viewPager;



    public Track() {
        // Required empty public constructor
    }


    private EditText date, time;
    private TextView tripid;
    private Button reset, search, live, faulty;


    RecyclerView recyclerView;
    ArrayList<datamodel> smsholder = new ArrayList<>();

    String currentDate, currentTime;



    private final static int REQUEST_CODE_PERMISSION_READ_SMS = 456;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_track, container, false);



        SmsAdapter adapter = new SmsAdapter(smsholder,getContext());

        //adding new tab layout with viewpager as child fragment inside a parent fragment
//        tabLayout = (TabLayout) view.findViewById(R.id.tablayout2);
//        viewPager = (ViewPager) view.findViewById(R.id.viewPager);
//        TrackFragmentsAdapter trackFragmentsAdapter = new TrackFragmentsAdapter(getChildFragmentManager());
//        tabLayout.setupWithViewPager(viewPager);
//        viewPager.setAdapter(trackFragmentsAdapter);


        date = (EditText) view.findViewById(R.id.editTextDate);
        time = (EditText) view.findViewById(R.id.editTextTime);
        tripid = (TextView) view.findViewById(R.id.TripID);


        reset = (Button) view.findViewById(R.id.reset);
        search = (Button) view.findViewById(R.id.search);
        live = (Button) view.findViewById(R.id.live);
        faulty = (Button) view.findViewById(R.id.faulty);


        //set recycler view
        recyclerView = view.findViewById(R.id.recview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        currentTime = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        date.setText(currentDate);
        time.setText(currentTime);
        tripid.setText(currentDate + "-" + currentTime);

        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DATE);
        final int hour = calendar.get(Calendar.HOUR);
        final int minute = calendar.get(Calendar.MINUTE);


        //check permission when using the tasks always
        if(checkPermission(Manifest.permission.READ_SMS)){
            refreshInbox(adapter);
        }
        else{
            ActivityCompat.requestPermissions(getActivity(), new String[] {
                    (Manifest.permission.READ_SMS) }, REQUEST_CODE_PERMISSION_READ_SMS);
        }


        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        getContext(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        String datestring = null;
                        i1 = i1 + 1;
                        if (i2 < 10) {
                            datestring = "0" + i2;
                        }
                        else{
                            datestring = "" + i2;
                        }
                        if (i1 < 10){
                            datestring = datestring + "-0" + i1;
                        }
                        else{
                            datestring = datestring + "-" + i1;
                        }
                        datestring = datestring + "-" +i;
                        currentDate = datestring;
                        date.setText(datestring);
                        tripid.setText(currentDate + "-" + currentTime);
                    }
                },year, month, day);
                datePickerDialog.show();

            }
        });


        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                TimePickerDialog timePickerDialog = new TimePickerDialog(
                        getContext(), new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int i, int i1) {
                        String timestring = null;
                        if (i<10){
                            timestring = "0" + i;
                        }
                        else{
                            timestring = "" + i;
                        }
                        if (i1<10){
                            timestring = timestring + ":0" + i1;
                        }
                        else{
                            timestring = timestring + ":" + i1;
                        }

                        currentTime = timestring;
                        time.setText(timestring);
                        tripid.setText(currentDate + "-" + currentTime);
                    }
                }, hour, minute, true);
                timePickerDialog.show();
            }
        });




        //Search function to search sms when entered date and time then click search
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String entered_date = date.getText().toString();
                String entered_time = time.getText().toString();

                if(!entered_date.isEmpty() && !entered_time.isEmpty()) {

                    Toast.makeText(getContext(), "Sms list of " + entered_date, Toast.LENGTH_SHORT ).show();
                    search_sms_by_date(entered_date, adapter);
//                    Bundle bundle = new Bundle();
//                    bundle.putString("Date", entered_date);
//                    Live live = new Live();
//                    live.setArguments(bundle);
//                    SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
//                    SharedPreferences.Editor editor = sharedPreferences.edit();
//                    editor.putString("date", entered_date);
//                    editor.apply();






                }
                else{
                    Toast.makeText(getContext(), "Enter the details", Toast.LENGTH_SHORT).show();
                }
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                String currentTime = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
                date.setText(currentDate);
                time.setText(currentTime);
                tripid.setText(currentDate + "-" + currentTime);
                Toast.makeText(getContext(), "Reset", Toast.LENGTH_SHORT).show();
                refreshInbox(adapter);

            }
        });

        live.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(), "List of Live Trips", Toast.LENGTH_SHORT).show();
                refreshInbox(adapter);
            }
        });

        faulty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(), "List Of Faulty Trip SMS",Toast.LENGTH_SHORT).show();
                smsholder.clear();
                adapter.notifyDataSetChanged();
            }
        });




        recyclerView.setAdapter(adapter);
        return view;
    }



    public void search_sms_by_date(String entered_date, SmsAdapter adapter){
        //smsholder.clear();
        ContentResolver cResolver = getActivity().getContentResolver();
        Cursor smsInboxCursor = cResolver.query(Uri.parse("content://sms/inbox"),
                null ,null, null, null);


        int indexBody = smsInboxCursor.getColumnIndex("body");
        int indexAddress = smsInboxCursor.getColumnIndex("address");
        int indexDate = smsInboxCursor.getColumnIndex("date");

        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat tf = new SimpleDateFormat("HH:mm");



        if(indexBody <0 || !smsInboxCursor.moveToFirst())
            return;

        smsholder.clear();

        do {

            String date, time, body, sender;
            sender = smsInboxCursor.getString(indexAddress);
            body = smsInboxCursor.getString(indexBody);
            date = df.format(smsInboxCursor.getLong(indexDate));
            time = tf.format(smsInboxCursor.getLong(indexDate));


            if (entered_date.equals(date)){
                datamodel obj = new datamodel(sender , date, time, body);
                smsholder.add(obj);
            }


        }while (smsInboxCursor.moveToNext());
        adapter.notifyDataSetChanged();




    }

    public void refreshInbox(SmsAdapter adapter){
        ContentResolver cResolver = getActivity().getContentResolver();
        Cursor smsInboxCursor = cResolver.query(Uri.parse("content://sms/inbox"),
                null ,null, null, null);

        date.setText(new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date()));
        time.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));

        int indexBody = smsInboxCursor.getColumnIndex("body");
        int indexAddress = smsInboxCursor.getColumnIndex("address");
        int indexDate = smsInboxCursor.getColumnIndex("date");



        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat tf = new SimpleDateFormat("HH:mm");

        if(indexBody <0 || !smsInboxCursor.moveToFirst())
            return;

        smsholder.clear();


        do {
            String date, time, body, sender;
            sender = smsInboxCursor.getString(indexAddress);
            body = smsInboxCursor.getString(indexBody);
            date = df.format(smsInboxCursor.getLong(indexDate));
            time = tf.format(smsInboxCursor.getLong(indexDate));

            datamodel obj = new datamodel(sender , date, time, body);
            smsholder.add(obj);


            //String date = millisToDate(smsInboxCursor.getLong(indexDate));
            //String str = "\nSMS from : " + smsInboxCursor.getString(indexAddress) + "\n" + "Date : " + date + "\n";
            //str += smsInboxCursor.getString(indexBody) + "\n";
            //arrayAdapter.add(str);
        }while (smsInboxCursor.moveToNext());

        adapter.notifyDataSetChanged();


    }
    private boolean checkPermission(String permission){
        int checkPermission = ContextCompat.checkSelfPermission(getContext(), permission);
        return checkPermission == PackageManager.PERMISSION_GRANTED;
    }

}