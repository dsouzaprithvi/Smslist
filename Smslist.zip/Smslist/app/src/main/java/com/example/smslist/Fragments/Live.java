package com.example.smslist.Fragments;



import android.Manifest;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.smslist.Adapter.SmsAdapter;
import com.example.smslist.Models.datamodel;
import com.example.smslist.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;


public class Live extends Fragment {



    public Live() {
        // Required empty public constructor
    }


    RecyclerView recyclerView;
    ArrayList<datamodel> smsholder = new ArrayList<>();

    String currentDate, currentTime, datesearch;





    private final static int REQUEST_CODE_PERMISSION_READ_SMS = 456;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_live, container, false);

        SmsAdapter adapter = new SmsAdapter(smsholder,getContext());

        recyclerView = view.findViewById(R.id.recview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        //check permission when using the tasks always
        if(checkPermission(Manifest.permission.READ_SMS)){
            refreshInbox(adapter);
        }
        else{
            ActivityCompat.requestPermissions(getActivity(), new String[] {
                    (Manifest.permission.READ_SMS) }, REQUEST_CODE_PERMISSION_READ_SMS);
        }



//        Bundle bundle = getArguments();
//
//        bundle = getParentFragment().getArguments();
//
//        String entered_date = bundle.getString("Date");


        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        String entered_date = sharedPreferences.getString("date", "");

        search_sms_by_date(entered_date, adapter);



        recyclerView.setAdapter(adapter);
        return view;
    }

    public void search_sms_by_date(String entered_date, SmsAdapter adapter){
        //smsholder.clear();
        ContentResolver cResolver = getActivity().getContentResolver();
        Cursor smsInboxCursor = cResolver.query(Uri.parse("content://sms/inbox"),
                null ,null, null, null);


        int indexBody = smsInboxCursor.getColumnIndex("body");
        int indexAddress = smsInboxCursor.getColumnIndex("address");
        int indexDate = smsInboxCursor.getColumnIndex("date");

        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat tf = new SimpleDateFormat("HH:mm");



        if(indexBody <0 || !smsInboxCursor.moveToFirst())
            return;

        smsholder.clear();

        do {

            String date, time, body, sender;
            sender = smsInboxCursor.getString(indexAddress);
            body = smsInboxCursor.getString(indexBody);
            date = df.format(smsInboxCursor.getLong(indexDate));
            time = tf.format(smsInboxCursor.getLong(indexDate));


            if (entered_date.equals(date)){
                datamodel obj = new datamodel(sender , date, time, body);
                smsholder.add(obj);
            }


        }while (smsInboxCursor.moveToNext());
        adapter.notifyDataSetChanged();




    }

    public void refreshInbox(SmsAdapter adapter){
        ContentResolver cResolver = getActivity().getContentResolver();
        Cursor smsInboxCursor = cResolver.query(Uri.parse("content://sms/inbox"),
                null ,null, null, null);

//        date.setText(new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date()));
//        time.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));

        int indexBody = smsInboxCursor.getColumnIndex("body");
        int indexAddress = smsInboxCursor.getColumnIndex("address");
        int indexDate = smsInboxCursor.getColumnIndex("date");



        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat tf = new SimpleDateFormat("HH:mm");

        if(indexBody <0 || !smsInboxCursor.moveToFirst())
            return;

        smsholder.clear();


        do {
            String date, time, body, sender;
            sender = smsInboxCursor.getString(indexAddress);
            body = smsInboxCursor.getString(indexBody);
            date = df.format(smsInboxCursor.getLong(indexDate));
            time = tf.format(smsInboxCursor.getLong(indexDate));

            datamodel obj = new datamodel(sender , date, time, body);
            smsholder.add(obj);


            //String date = millisToDate(smsInboxCursor.getLong(indexDate));
            //String str = "\nSMS from : " + smsInboxCursor.getString(indexAddress) + "\n" + "Date : " + date + "\n";
            //str += smsInboxCursor.getString(indexBody) + "\n";
            //arrayAdapter.add(str);
        }while (smsInboxCursor.moveToNext());

        adapter.notifyDataSetChanged();


    }
    private boolean checkPermission(String permission){
        int checkPermission = ContextCompat.checkSelfPermission(getContext(), permission);
        return checkPermission == PackageManager.PERMISSION_GRANTED;
    }
}