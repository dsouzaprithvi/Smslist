package com.example.smslist.Fragments;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.core.util.Pair;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.smslist.R;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;

import java.util.ArrayList;
import java.util.Calendar;


public class Report extends Fragment {

    EditText fromdate, todate,dateRangeText;
    DatePickerDialog.OnDateSetListener setListener;
    TextView select_method;

    Spinner spinner;
    ArrayList<String> method;
    String selected_method = "";

    ArrayAdapter<String> adapter;



    public Report() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_report, container, false);



        select_method = (TextView) view.findViewById(R.id.method);
        dateRangeText = (EditText) view.findViewById(R.id.date_selection);


        method = new ArrayList<>();
        method.add("Daily");
        method.add("Weekly");
        method.add("Monthly");
        method.add("Yearly");
        method.add("Custom");




        spinner = (Spinner) view.findViewById(R.id.select_method);
        adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, method);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(adapter);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {

                switch (position){
                    case 0:
                        selected_method = "Daily";
                        method(selected_method);
                        break;

                    case 1:
                        selected_method = "Weekly";
                        method(selected_method);
                        break;
                    case 2:
                        selected_method = "Monthly";
                        method(selected_method);
                        break;
                    case 3:
                        selected_method = "Yearly";
                        method(selected_method);
                        break;
                    case 4:
                        selected_method = "Custom";
                        method(selected_method);
                        break;
                }


            }


            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);

        MaterialDatePicker materialDatePicker = MaterialDatePicker.Builder.dateRangePicker().
                setSelection(Pair.create(MaterialDatePicker.thisMonthInUtcMilliseconds(),
                        MaterialDatePicker.todayInUtcMilliseconds())).build();


//        fromdate.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                String meth = select_method.getText().toString();
//
//                    DatePickerDialog datePickerDialog = new DatePickerDialog(
//                            getContext(), new DatePickerDialog.OnDateSetListener() {
//                        @Override
//                        public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
//                            i1 = i1 + 1;
//
//                            show_date(meth, i2, i1, i);
//
//
//
//                        }
//                    },year, month, day);
//                    datePickerDialog.show();
//
//
//
//            }
//        });

//        fromdate.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                DatePickerDialog datePickerDialog = new DatePickerDialog(
//                        getContext(), android.R.style.Theme_Holo_Light_Dialog_MinWidth, setListener,
//                        year, month, day);
//                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//                datePickerDialog.show();
//            }
//        });
//
//        setListener = new DatePickerDialog.OnDateSetListener() {
//            @Override
//            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
//                i1 = i1+1;
//                String date = i2+"-"+i1+"-"+i;
//                fromdate.setText(date);
//
//
//            }
//        };

//        todate.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                DatePickerDialog datePickerDialog = new DatePickerDialog(
//                        getContext(), new DatePickerDialog.OnDateSetListener() {
//                    @Override
//                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
//                        i1 = i1 + 1;
//                        String date = i2+"-"+i1+"-"+i;
//                        todate.setText(date);
//                    }
//                },year, month, day);
//                datePickerDialog.show();
//            }
//        });



        dateRangeText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                materialDatePicker.show(getActivity().getSupportFragmentManager(), "Tag_picker");
                materialDatePicker.addOnPositiveButtonClickListener(new MaterialPickerOnPositiveButtonClickListener() {
                    @Override
                    public void onPositiveButtonClick(Object selection) {
                        dateRangeText.setText(materialDatePicker.getHeaderText());
                    }
                });
            }
        });




        return view;
    }

    private void show_date(String meth, int i2, int i1, int i) {
        if ( meth.equals("Daily\nReport")){
            String date = i2+"-"+i1+"-"+i;
            fromdate.setText(date);
            todate.setVisibility(View.INVISIBLE);
        }


    }

    private void method(String position) {


        select_method.setText(position + "\nReport");


    }
}