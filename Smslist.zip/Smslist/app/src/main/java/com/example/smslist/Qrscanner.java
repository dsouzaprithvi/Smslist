package com.example.smslist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.budiyev.android.codescanner.CodeScanner;
import com.budiyev.android.codescanner.CodeScannerView;
import com.budiyev.android.codescanner.DecodeCallback;
import com.google.zxing.Result;

public class Qrscanner extends AppCompatActivity {

    private CodeScanner mCodeScanner;
    private static final int REQUEST_CODE_PERMISSION_CAMERA = 200;

    Button add , reset;
    EditText deviceid, truckid, employeeid, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrscanner);


        add = findViewById(R.id.add);
        reset = findViewById(R.id.reset);

        deviceid = findViewById(R.id.device_id);
        truckid = findViewById(R.id.truck_id);
        employeeid = findViewById(R.id.employee_id);
        password = findViewById(R.id.password);

        CodeScannerView scannerView = findViewById(R.id.scanner_view);
        mCodeScanner = new CodeScanner(this, scannerView);



        mCodeScanner.setDecodeCallback(new DecodeCallback() {
            @Override
            public void onDecoded(@NonNull final Result result) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(Qrscanner.this, result.getText(), Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(Qrscanner.this, smslisting.class);
                        intent.putExtra("Code", result.getText());
                        startActivity(intent);
                    }
                });
            }
        });
        scannerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCodeScanner.startPreview();
            }
        });







        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String result = deviceid.getText().toString() + "\n" + truckid.getText().toString()
                        + "\n" + employeeid.getText().toString() + "\n" + password.getText().toString();

                Toast.makeText(Qrscanner.this, result, Toast.LENGTH_SHORT).show();Intent intent = new Intent(Qrscanner.this, smslisting.class);
                intent.putExtra("ManualCode", result);
                startActivity(intent);
            }
        });



    }

    @Override
    protected void onResume() {
        super.onResume();
        mCodeScanner.startPreview();
    }

    @Override
    protected void onPause() {
        mCodeScanner.releaseResources();
        super.onPause();
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_CODE_PERMISSION_CAMERA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                add.setEnabled(true);
            }
        }
    }
}
