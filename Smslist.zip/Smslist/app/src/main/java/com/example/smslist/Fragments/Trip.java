package com.example.smslist.Fragments;

import static android.content.ContentValues.TAG;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.util.Pair;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Database;

import android.preference.Preference;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.smslist.Adapter.SmsAdapter;
import com.example.smslist.Adapter.TripsAdapter;
import com.example.smslist.Models.datamodel;
import com.example.smslist.Models.tripmodel;
import com.example.smslist.R;
import com.example.smslist.SMSView;
import com.google.android.gms.tasks.Task;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
//import com.example.smslist.databinding.FragmentSmslistingBinding;


import java.lang.reflect.Type;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


public class Trip extends Fragment {

    FirebaseDatabase database;
    DatabaseReference databaseReference;


    public Trip() {
        // Required empty public constructor
    }


    private TextView tripid, truckid, deviceid;
    private EditText time, date;
    private Button reset, add;

    ArrayList<tripmodel> tripholer;
    RecyclerView recyclerView;

    String currentDate, currentTime;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_trip, container, false);

        database = FirebaseDatabase.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();





//        load_data();





        if(tripholer == null){
            tripholer = new ArrayList<>();
        }


//        database.getReference().child("users").child("+91 9743022825").child("trips")
//                .addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(@NonNull DataSnapshot snapshot) {
////                        tripholer.clear();
//                        for (DataSnapshot dataSnapshot : snapshot.getChildren()){
//
//                            String trip = dataSnapshot.getValue(String.class);
//                            Toast.makeText(getContext(), trip, Toast.LENGTH_SHORT);
////                            tripmodel trip = dataSnapshot.getValue(tripmodel.class);
////                            trip.getTripid(dataSnapshot.getKey());
////                            tripholer.add(trip);
//
//                        }
//                    }
//
//                    @Override
//                    public void onCancelled(@NonNull DatabaseError error) {
//
//                    }
//                });





        TripsAdapter adapter = new TripsAdapter(tripholer, getContext());


//        databaseReference.child("users").child("+91 9743022825").child("trips").child("15-01-2022-22:36");

        database.getReference().child("users").child("+91 9743022825").child("trips")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        tripholer.clear();
                        for(DataSnapshot dataSnapshot: snapshot.getChildren()){
                            tripmodel trip = dataSnapshot.getValue(tripmodel.class);
                            trip.setBody(trip.getTripid()+trip.getDate());
                            tripholer.add(trip);
                        }
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Log.w("ERROR", error.toException());

                    }
                });




        // set recyclerview
        recyclerView = view.findViewById(R.id.recview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(linearLayoutManager);


        //Hooks
        date = (EditText) view.findViewById(R.id.date);
        time = (EditText) view.findViewById(R.id.time);
        tripid = (TextView) view.findViewById(R.id.trip_id);
        truckid = (TextView) view.findViewById(R.id.truck_id);
        deviceid = (TextView) view.findViewById(R.id.device_id);
        add = (Button) view.findViewById(R.id.add);
        reset = (Button) view.findViewById(R.id.reset);








        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        currentTime = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        date.setText(currentDate);
        time.setText(currentTime);
        tripid.setText(currentDate + "-" + currentTime);
        truckid.setText("VECHILCE NUMBER");
        deviceid.setText("+91 9876543210");


        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DATE);
        final int hour = calendar.get(Calendar.HOUR);
        final int minute = calendar.get(Calendar.MINUTE);






        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        getContext(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        String datestring = null;
                        i1 = i1 + 1;
                        if (i2 < 10) {
                            datestring = "0" + i2;
                        }
                        else{
                            datestring = "" + i2;
                        }
                        if (i1 < 10){
                            datestring = datestring + "-0" + i1;
                        }
                        else{
                            datestring = datestring + "-" + i1;
                        }
                        datestring = datestring + "-" +i;
                        currentDate = datestring;
                        date.setText(datestring);
                        tripid.setText(currentDate + "-" + currentTime);
                    }
                },year, month, day);
                datePickerDialog.show();

            }
        });


        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                TimePickerDialog timePickerDialog = new TimePickerDialog(
                        getContext(), new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int i, int i1) {
                        String timestring = null;
                        if (i<10){
                            timestring = "0" + i;
                        }
                        else{
                            timestring = "" + i;
                        }
                        if (i1<10){
                            timestring = timestring + ":0" + i1;
                        }
                        else{
                            timestring = timestring + ":" + i1;
                        }
                        
                        currentTime = timestring;
                        time.setText(timestring);
                        tripid.setText(currentDate + "-" + currentTime);
                    }
                }, hour, minute, true);
                timePickerDialog.show();
            }
        });








        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                String trip, edate, etime, ebody, truckno, deviceno;
                trip = tripid.getText().toString();
                edate = date.getText().toString();
                etime = time.getText().toString();
                truckno = truckid.getText().toString();
                deviceno = deviceid.getText().toString();
                ebody = "Truck ID : " + truckno + "\nDevice ID : " + deviceno +
                        "\nTrip ID : " + trip + "\n" + "Date : " + edate + "\n" + "Time :" + etime;
                Toast.makeText(getContext(),"New Trip Added",Toast.LENGTH_LONG ).show();
                tripmodel obj = new tripmodel(trip, edate, etime, ebody);
                tripmodel obj1 = new tripmodel(trip, edate, etime);
                //tripholer.add(obj);

//              storing trip information in firebase
                String mobilenumber = "+91 9743022825";
//                database = FirebaseDatabase.getInstance().getReference("users/+91 9743022825/trips/tri");
//                database.setValue(obj);
                database.getReference().child("users").child(mobilenumber).child("trips").child(trip).setValue(obj1);


                //adapter.notifyDataSetChanged();


                save_data();



            }
        });


        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                String currentTime = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
                date.setText(currentDate);
                time.setText(currentTime);
                tripid.setText(currentDate + "-" + currentTime);


                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.clear();
                editor.commit();
                tripholer.clear();
                adapter.notifyDataSetChanged();

                Toast.makeText(getContext(), "Reset", Toast.LENGTH_SHORT).show();
            }


        });


        recyclerView.setAdapter(adapter);
        return view;


    }

    private void save_data(){
        Gson gson = new Gson();
        String jsonstring = gson.toJson(tripholer);


        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("trip_list", jsonstring);
        editor.apply();

    }

    private void load_data(){




        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        String jsonString = sharedPreferences.getString("trip_list", "");

        Gson gson = new Gson();
        Type type = new TypeToken<ArrayList<tripmodel>>() {}.getType();
        tripholer = gson.fromJson(jsonString, type);

        if(tripholer == null){
            tripholer = new ArrayList<>();
        }
    }



}








