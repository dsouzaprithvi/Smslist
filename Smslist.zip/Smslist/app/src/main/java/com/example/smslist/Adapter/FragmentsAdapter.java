package com.example.smslist.Adapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.example.smslist.Fragments.Track;
import com.example.smslist.Fragments.Report;
import com.example.smslist.Fragments.Trip;

public class FragmentsAdapter extends FragmentStatePagerAdapter {

    public FragmentsAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }



    @NonNull
    @Override
    public Fragment getItem(int position) {

        switch (position){

            case 0: return new Trip();

            case 1: return new Track();

            case 2: return new Report();

            default: return new Trip();

        }

    }

    @Override
    public int getCount() {
        return 3;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        String title = null;
        if (position == 0){
            title = "Trip";
        }
        if (position == 1){
            title = "Track";
        }
        if (position == 2){
            title = "Report";
        }
        return title;

    }
}
