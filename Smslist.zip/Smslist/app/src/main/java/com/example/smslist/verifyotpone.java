package com.example.smslist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class verifyotpone extends AppCompatActivity {
    EditText enternumber;
    Button getotpbutton, skipotp;
    com.hbb20.CountryCodePicker countrycode;
    String mobilenumber;
    ProgressBar progressBar;
    FirebaseAuth auth;

    private final static int REQUEST_CODE_PERMISSION_SEND_SMS = 123;
    private final static int REQUEST_CODE_PERMISSION_READ_SMS = 456;
    private static final int REQUEST_CODE_PERMISSION_CAMERA = 200;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verifyotpone);

        enternumber = findViewById(R.id.input_mobile_number);
        getotpbutton = findViewById(R.id.buttongetotp);
        countrycode = findViewById(R.id.ccp);
        progressBar = findViewById(R.id.progressbar_sending_otp);
        skipotp = findViewById(R.id.skip_otp);

        auth = FirebaseAuth.getInstance();



        getotpbutton.setEnabled(false);

        //setting the project display bar not to be seen
        //Objects.requireNonNull(getSupportActionBar()).hide();







        if(checkPermission(Manifest.permission.SEND_SMS)){
            getotpbutton.setEnabled(true);
        }
        else{
            ActivityCompat.requestPermissions(verifyotpone.this, new String[] {
                    (Manifest.permission.SEND_SMS) }, REQUEST_CODE_PERMISSION_READ_SMS);
        }
        if(checkPermission(Manifest.permission.CAMERA)){
            getotpbutton.setEnabled(true);
        }
        else{
            ActivityCompat.requestPermissions(verifyotpone.this, new String[] {
                    (Manifest.permission.CAMERA) }, REQUEST_CODE_PERMISSION_CAMERA);
        }






        getotpbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if(checkPermission(Manifest.permission.SEND_SMS)){
                    getotpbutton.setEnabled(true);
                }
                else{
                    ActivityCompat.requestPermissions(verifyotpone.this, new String[] {
                            (Manifest.permission.SEND_SMS) }, REQUEST_CODE_PERMISSION_SEND_SMS);
                }




                if(!enternumber.getText().toString().trim().isEmpty()){
                    if((enternumber.getText().toString().trim()).length() == 10){
                        mobilenumber = countrycode.getSelectedCountryCodeWithPlus().toString() + " " + enternumber.getText().toString();
                        Log.i("Mobile",mobilenumber);
                        Intent intent = new Intent(getApplicationContext(),verifyotptwo.class);
                        intent.putExtra("mobile",mobilenumber);
                        //intent.putExtra("backendotp", backendotp);
                        //Log.i("otp",backendotp);
                        startActivity(intent);
                        //finish();

                        //When clicking send otp button becomes visible
//                        progressBar.setVisibility(View.VISIBLE);
//                        getotpbutton.setVisibility(View.INVISIBLE);


//                        PhoneAuthProvider.getInstance().verifyPhoneNumber(mobilenumber, 60, TimeUnit.SECONDS, verifyotpone.this,
//                                new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
//
//                                    @Override
//                                    public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
//
//                                        String otp = phoneAuthCredential.getSmsCode();
//                                        progressBar.setVisibility(View.GONE);
//                                        getotpbutton.setVisibility(View.VISIBLE);
//
//
//                                    }
//
//                                    @Override
//                                    public void onVerificationFailed(@NonNull FirebaseException e) {
//
//                                        progressBar.setVisibility(View.GONE);
//                                        getotpbutton.setVisibility(View.VISIBLE);
//
//                                        Toast.makeText(verifyotpone.this, e.getMessage(), Toast.LENGTH_SHORT).show();
//
//                                    }
//
//                                    @Override
//                                    public void onCodeSent(@NonNull String backendotp, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
//
//
//                                        progressBar.setVisibility(View.GONE);
//                                        getotpbutton.setVisibility(View.VISIBLE);
//
//                                        Intent intent = new Intent(getApplicationContext(),verifyotptwo.class);
//                                        intent.putExtra("mobile",mobilenumber);
//                                        intent.putExtra("backendotp", backendotp);
//                                        Log.i("otp",backendotp);
//                                        startActivity(intent);
//                                    }
//                                });




                    } else {
                        Toast.makeText( verifyotpone.this, "Please enter correct number", Toast.LENGTH_SHORT).show();
                    }

                }else {
                    Toast.makeText( verifyotpone.this, "Enter mobile number", Toast.LENGTH_SHORT).show();
                }

            }
        });

        skipotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(verifyotpone.this, smslisting.class);
                startActivity(intent);
                finish();

            }
        });

        if(auth.getCurrentUser()!=null){

            Intent intent = new Intent(verifyotpone.this, smslisting.class);
            startActivity(intent);
            finish();
        }


    }


    private boolean checkPermission(String permission){
        int checkPermission = ContextCompat.checkSelfPermission(this, permission);
        return checkPermission == PackageManager.PERMISSION_GRANTED;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_CODE_PERMISSION_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getotpbutton.setEnabled(true);
            }
        }
    }
}