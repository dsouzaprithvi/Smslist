package com.example.smslist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Objects;


public class Splashscreen extends AppCompatActivity {


    public static int SPLASH_SCREEN = 4000;


    //Variables

    Animation topanim, bottomanim;
    ImageView logoimage;
    TextView name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashscreen);

        //setting the project display bar not to be seen
        //Objects.requireNonNull(getSupportActionBar()).hide();

        //Animations
        topanim = AnimationUtils.loadAnimation(this, R.anim.top_animation);
        bottomanim = AnimationUtils.loadAnimation(this, R.anim.bottom_animation);

        //hooks
        logoimage = findViewById(R.id.logo);



        logoimage.setAnimation(topanim);



        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                Intent intent = new Intent(Splashscreen.this, verifyotpone.class);
                startActivity(intent);
                finish();

            }
        },SPLASH_SCREEN);





    }
}