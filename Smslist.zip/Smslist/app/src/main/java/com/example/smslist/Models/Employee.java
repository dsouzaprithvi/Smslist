package com.example.smslist.Models;

public class Employee {


    String employeeid, deviceid, truckid, trips;

    public Employee(String employeeid, String deviceid, String truckid, String trips) {
        this.employeeid = employeeid;
        this.deviceid = deviceid;
        this.truckid = truckid;
        this.trips = trips;
    }


    public Employee(){


    }

    public Employee(String employeeid){
        this.employeeid =employeeid;

    }


    public String getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(String employeeid) {
        this.employeeid = employeeid;
    }

    public String getDeviceid() {
        return deviceid;
    }

    public void setDeviceid(String deviceid) {
        this.deviceid = deviceid;
    }

    public String getTruckid() {
        return truckid;
    }

    public void setTruckid(String truckid) {
        this.truckid = truckid;
    }

    public String getTrips() {
        return trips;
    }

    public void setTrips(String trips) {
        this.trips = trips;
    }
}
