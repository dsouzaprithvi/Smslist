package com.example.smslist;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.util.Objects;

public class SMSView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smsview);

        //Objects.requireNonNull(getSupportActionBar()).hide();

        TextView sms = findViewById(R.id.Message);
        sms.setText(getIntent().getStringExtra("SMS"));

    }
}