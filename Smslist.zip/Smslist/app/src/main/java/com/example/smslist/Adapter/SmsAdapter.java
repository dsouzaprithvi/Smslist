package com.example.smslist.Adapter;

import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smslist.Models.datamodel;
import com.example.smslist.R;
import com.example.smslist.SMSView;

import java.util.ArrayList;

public class SmsAdapter extends RecyclerView.Adapter<SmsAdapter.smsViewHolder> {


    ArrayList<datamodel> dataholder;
    Context context;


    public SmsAdapter(ArrayList<datamodel> dataholder, Context context) {
        this.dataholder = dataholder;
        this.context = context;
    }


    @NonNull
    @Override
    public SmsAdapter.smsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_design, parent, false);
        return new smsViewHolder(view);


    }

    @Override
    public void onBindViewHolder(@NonNull SmsAdapter.smsViewHolder holder, int position) {

        datamodel data = dataholder.get(position);

        holder.sender.setText(dataholder.get(position).getSender());
        holder.body.setText(dataholder.get(position).getBody());
        holder.date.setText(dataholder.get(position).getDate());
        holder.time.setText(dataholder.get(position).getTime());


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(context, SMSView.class);
                String Sms = "Sms from :" + data.getSender()  + "\n" + data.getBody();
                intent.putExtra("SMS", Sms);


                context.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return dataholder.size();
    }

    public class smsViewHolder extends RecyclerView.ViewHolder{

        TextView sender, body, date, time;


        public smsViewHolder(@NonNull View itemView) {
            super(itemView);
            sender = itemView.findViewById(R.id.sms_sender);
            body = itemView.findViewById(R.id.sms_body);
            date = itemView.findViewById(R.id.sms_date);
            time = itemView.findViewById(R.id.sms_time);
        }
    }
}


